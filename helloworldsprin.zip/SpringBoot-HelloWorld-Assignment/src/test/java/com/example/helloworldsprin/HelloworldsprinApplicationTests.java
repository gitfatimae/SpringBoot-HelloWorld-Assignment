package com.example.helloworldsprin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldsprinApplicationTests {

	@Test
	void contextLoads() {
	}

}
